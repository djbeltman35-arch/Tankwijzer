# Tankwijzer installeren

## 1. Online zetten (eenmalig, ±2 minuten)
1. Pak de zip uit. Je krijgt een map `tankwijzer-app`.
2. Ga op je computer naar **app.netlify.com/drop** en maak een gratis account (of log in).
3. Sleep de hele map `tankwijzer-app` naar het vak op die pagina.
4. Netlify geeft je een adres, bijvoorbeeld `https://vrolijke-naam-123.netlify.app`. Via *Site configuration › Change site name* kun je dat veranderen in bijvoorbeeld `mijn-tankwijzer`.

Een update later? Sleep de nieuwe map op dezelfde site onder *Deploys*.

## 2. Op je telefoon installeren
- **iPhone (Safari):** open het adres › deelknop › *Zet op beginscherm*.
- **Android (Chrome):** open het adres › menu ⋮ › *App installeren*.

De app opent daarna schermvullend met een eigen icoon, ook zonder internet (met de laatst bekende prijzen).

## 3. Live Duitse prijzen aanzetten
1. Vraag een gratis API-sleutel aan op **onboarding.tankerkoenig.de**.
2. Open de app › *Meer* › plak de sleutel › *Opslaan*.

Tot die tijd kun je onder *Meer* op *Probeer demodata* tikken om te zien hoe het werkt (geen echte prijzen).

## Wat zit erin
- **Stations:** alle Duitse stations binnen 10 km van de grens per regio, met kleurcode (goedkoop/gemiddeld/duur), netto besparing vanaf jouw vertrekpunt, filters op merk, open, snelweg en favorieten (☆). Tik op een station voor openingstijden, alle prijzen en navigatie via Google Maps of Waze.
- **Kaart:** dezelfde stations op de kaart, met grenslijn en je vertrekpunt.
- **Dagprijzen:** Nederlandse pompprijs per dag (CBS) met dag-op-dag verschil, naast het Duitse gemiddelde van de grensstrook.
- **Bespaar:** vertrekpunt en auto instellen, beste station met netto besparing per keer en per jaar, logboek van je tankbeurten, prijs-check en "Dichtbij mij".
- **Meer:** API-sleutel, prijsalarm met melding, tips.

Stel eerst onder *Bespaar* je vertrekpunt, liters en verbruik in; de regio wordt dan automatisch gekozen.

## Hoe actueel zijn de prijzen?
- **Duitsland:** live via Tankerkönig (officiële Markttransparenzstelle; stations moeten wijzigingen binnen minuten melden). De app ververst bij elke start, zodra je hem weer opent, en elke 5 minuten zolang hij openstaat.
- **Nederland:** CBS-gemiddelde pompprijs per dag (verschijnt met een paar dagen vertraging). Vul onder *Bespaar* je eigen Nederlandse prijs in als je bij een goedkoper station tankt.
- **Afstand tot de grens** is benaderd (±2–3 km).

## Werkt het niet?
- *"Tankerkönig is niet bereikbaar"*: controleer je internet en probeer *Ververs*. Blijft het, laat het Claude weten.
- *"Sleutel wordt niet geaccepteerd"*: de sleutel is pas actief na bevestiging per e-mail.

Bronnen: Tankerkönig (CC BY 4.0), CBS StatLine 80416ned, kaart © OpenStreetMap.
