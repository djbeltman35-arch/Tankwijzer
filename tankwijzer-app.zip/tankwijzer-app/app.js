"use strict";
/* Tankwijzer — live Duitse grensprijzen (Tankerkönig) + Nederlandse dagprijzen (CBS) */

const API = "https://creativecommons.tankerkoenig.de/json/";
const DEMO_KEY = "00000000-0000-0000-0000-000000000002";
const PRICE_TTL = 5 * 60 * 1000;      // prijzen max. 5 minuten oud
const LIST_TTL = 12 * 60 * 60 * 1000; // stationslijst per regio 2x per dag opnieuw scannen
const CBS_TTL = 3 * 60 * 60 * 1000;
const ROAD = 1.3;                     // hemelsbreed → rijafstand
const FUELNAME = { e10: "Euro95 / E10", diesel: "Diesel", e5: "Super E5 / 98" };
const HWY = /\b(BAB|Autobahn|Rastst(ä|ae)tte|Tank\s*(&|und)\s*Rast|Serways)\b/i;

// Terugval als het CBS niet bereikbaar is (CBS dagprijzen, gemiddelde pompprijs incl. btw en accijns)
const CBS_FALLBACK = [
  ["20260920",2.449,2.572],["20260921",2.449,2.579],["20260922",2.443,2.562],["20260923",2.441,2.543],["20260924",2.444,2.539],
  ["20260925",2.459,2.536],["20260926",2.462,2.522],["20260927",2.463,2.522],["20260928",2.465,2.526],["20261001",2.437,2.518],
  ["20261002",2.433,2.519],["20261003",2.428,2.502],["20261004",2.427,2.499],["20261005",2.432,2.506],["20261006",2.432,2.496],
  ["20261007",2.434,2.472],["20261008",2.450,2.476],["20261009",2.455,2.482],["20261010",2.457,2.477],["20261011",2.457,2.477],
  ["20261012",2.462,2.482]
];
const NL_SUPER_ADVIES = { price: 2.904, date: "16 okt 2026" }; // UnitedConsumers adviesprijs Super; CBS meet geen E5/98

const CITIES = [
  ["Groningen",53.219,6.567],["Winschoten",53.144,7.035],["Emmen",52.785,6.897],["Coevorden",52.661,6.741],["Hardenberg",52.575,6.619],
  ["Zwolle",52.516,6.083],["Almelo",52.357,6.663],["Oldenzaal",52.313,6.929],["Hengelo",52.266,6.793],["Enschede",52.221,6.893],
  ["Winterswijk",51.972,6.719],["Doetinchem",51.965,6.289],["Apeldoorn",52.211,5.969],["Arnhem",51.985,5.899],["Zevenaar",51.930,6.071],
  ["Nijmegen",51.842,5.853],["Venlo",51.370,6.172],["Roermond",51.194,5.987],["Sittard",51.000,5.869],["Heerlen",50.888,5.980],
  ["Kerkrade",50.866,6.063],["Maastricht",50.851,5.690],["Eindhoven",51.441,5.478],["Utrecht",52.090,5.120],["Amsterdam",52.370,4.900],["Rotterdam",51.920,4.480]
];

const $ = (id) => document.getElementById(id);
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
};
const fmt = (n, d = 3) => (n == null || isNaN(n)) ? "–" : n.toLocaleString("nl-NL", { minimumFractionDigits: d, maximumFractionDigits: d });
const eur = (n) => (n < 0 ? "− " : "") + "€ " + Math.abs(n).toLocaleString("nl-NL", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const hhmm = (ts) => new Date(ts).toLocaleTimeString("nl-NL", { hour: "2-digit", minute: "2-digit" });
const ymd = (d) => d.getFullYear() + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0");
const todayKey = () => ymd(new Date());
const dayLabel = (k) => new Date(+k.slice(0, 4), +k.slice(4, 6) - 1, +k.slice(6, 8)).toLocaleDateString("nl-NL", { day: "numeric", month: "short" });

// ---------- state ----------
const S = {
  fuel: store.get("tw_fuel", "e10"),
  region: store.get("tw_region", "gelderland"),
  key: store.get("tw_key", ""),
  maxB: store.get("tw_maxB", 10),
  sort: store.get("tw_sort", "net"),
  brand: store.get("tw_brand", ""),
  openOnly: store.get("tw_open", true),
  noHwy: store.get("tw_nohwy", true),
  favOnly: store.get("tw_favonly", false),
  favs: new Set(store.get("tw_favs", [])),
  home: store.get("tw_home", { name: "Arnhem", lat: 51.985, lng: 5.899 }),
  nlOwn: store.get("tw_nlOwn", {}),
  cache: store.get("tw_cache", {}),
  hist: store.get("tw_hist", {}),
  cbs: store.get("tw_cbs", null),
  fills: store.get("tw_fills", []),
  alert: store.get("tw_alert", {}),
  alertLast: store.get("tw_alertLast", {}),
  details: {}, open: null,
  busy: false, error: "", tab: store.get("tw_tab", "lijst")
};
if (!FUELNAME[S.fuel]) S.fuel = "e10";
if (!REGIONS[S.region]) S.region = "gelderland";
const num = (v) => (typeof v === "number" && v > 0.5) ? v : null;
const settings = () => ({ L: +$("cLiters").value || 50, use: +$("cUse").value || 6.5, freq: +$("cFreq").value || 0 });

// ---------- Tankerkönig ----------
async function api(path, params) {
  const q = new URLSearchParams({ ...params, apikey: S.key });
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 15000);
  let res;
  try { res = await fetch(API + path + "?" + q, { signal: ctrl.signal, cache: "no-store" }); }
  catch (e) { throw new Error(navigator.onLine ? "Tankerkönig is niet bereikbaar. Probeer het straks opnieuw." : "Geen internetverbinding."); }
  finally { clearTimeout(t); }
  const j = await res.json().catch(() => ({}));
  if (!j.ok) throw new Error(/apikey/i.test(j.message || "") ? "De API-sleutel wordt niet geaccepteerd. Controleer hem onder Meer." : (j.message || "Onbekende fout van Tankerkönig."));
  return j;
}
function toStation(s) {
  return {
    id: s.id, name: s.name || "", brand: (s.brand || "").trim(), street: [s.street, s.houseNumber].filter(Boolean).join(" "),
    place: [s.postCode, s.place].filter(Boolean).join(" "), lat: s.lat, lng: s.lng,
    e5: num(s.e5), e10: num(s.e10), diesel: num(s.diesel), isOpen: !!s.isOpen,
    hwy: HWY.test(s.name || "") || HWY.test(s.street || "")
  };
}
async function scanRegion(region) {
  const byId = new Map();
  for (const [lat, lng] of REGIONS[region].pts) {
    const j = await api("list.php", { lat, lng, rad: 12, sort: "dist", type: "all" });
    for (const raw of j.stations || []) {
      if (byId.has(raw.id)) continue;
      const border = borderDistance(raw.lat, raw.lng);
      if (border > 10.5) continue;
      byId.set(raw.id, { ...toStation(raw), border });
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  const now = Date.now();
  S.cache[region] = { listTs: now, priceTs: now, stations: [...byId.values()] };
}
async function refreshPrices(region) {
  const c = S.cache[region]; if (!c) return;
  const map = new Map(c.stations.map((s) => [s.id, s])), ids = [...map.keys()];
  for (let i = 0; i < ids.length; i += 10) {
    const j = await api("prices.php", { ids: ids.slice(i, i + 10).join(",") });
    for (const [id, p] of Object.entries(j.prices || {})) {
      const s = map.get(id); if (!s) continue;
      s.isOpen = p.status === "open"; s.e5 = num(p.e5); s.e10 = num(p.e10); s.diesel = num(p.diesel);
    }
  }
  c.priceTs = Date.now();
}
function recordDay(region) {
  const c = S.cache[region]; if (!c) return;
  const k = todayKey(); S.hist[k] = S.hist[k] || {}; const day = (S.hist[k][region] = S.hist[k][region] || {});
  for (const f of ["e10", "diesel", "e5"]) {
    const ps = c.stations.filter((s) => s.isOpen && s[f] && !s.hwy).map((s) => s[f]);
    if (!ps.length) continue;
    const avg = ps.reduce((a, b) => a + b, 0) / ps.length, cur = day[f] || [0, 0];
    day[f] = [cur[0] + avg, cur[1] + 1];
  }
  const keys = Object.keys(S.hist).sort(); while (keys.length > 120) delete S.hist[keys.shift()];
  store.set("tw_hist", S.hist);
}
async function update(force = false) {
  if (!S.key || S.busy) { render(); return; }
  const region = S.region, c = S.cache[region], now = Date.now();
  const needList = force === "list" || !c || now - c.listTs > LIST_TTL;
  const needPrices = force || !c || now - c.priceTs > PRICE_TTL;
  if (!needList && !needPrices) { render(); return; }
  S.busy = true; S.error = ""; render();
  try {
    if (needList) await scanRegion(region); else await refreshPrices(region);
    recordDay(region); store.set("tw_cache", S.cache); checkAlert();
  } catch (e) { S.error = e.message; }
  S.busy = false; render();
}
async function loadDetail(id) {
  if (S.details[id]) return;
  try { const j = await api("detail.php", { id }); S.details[id] = j.station || {}; }
  catch (e) { S.details[id] = { error: e.message }; }
  render();
}

// ---------- CBS ----------
async function loadCBS() {
  if (S.cbs && Date.now() - S.cbs.ts < CBS_TTL) return;
  const k = ymd(new Date(Date.now() - 75 * 864e5));
  const url = "https://opendata.cbs.nl/ODataApi/odata/80416ned/TypedDataSet?$filter=" + encodeURIComponent(`Perioden ge '${k}'`) + "&$select=Perioden,BenzineEuro95_1,Diesel_2";
  try {
    const j = await (await fetch(url, { cache: "no-store" })).json();
    const rows = (j.value || []).filter((r) => r.BenzineEuro95_1).map((r) => [r.Perioden, r.BenzineEuro95_1, r.Diesel_2]).sort((a, b) => a[0].localeCompare(b[0]));
    if (rows.length) { S.cbs = { ts: Date.now(), rows }; store.set("tw_cbs", S.cbs); }
  } catch (e) { /* terugval blijft staan */ }
  render();
}
const cbsRows = () => (S.cbs?.rows?.length ? S.cbs.rows : CBS_FALLBACK);
function cbsOn(dateKey, fuel) { // CBS-prijs op of vlak vóór een datum
  const idx = fuel === "diesel" ? 2 : 1, rows = cbsRows();
  let best = rows[0]; for (const r of rows) if (r[0] <= dateKey) best = r;
  return best[idx];
}

// ---------- afgeleid ----------
function nlPrice(fuel = S.fuel) {
  if (S.nlOwn[fuel]) return { p: S.nlOwn[fuel], src: "Eigen ingevoerde prijs" };
  if (fuel === "e5") return { p: NL_SUPER_ADVIES.price, src: "Adviesprijs Super 98 · " + NL_SUPER_ADVIES.date };
  const rows = cbsRows(), last = rows[rows.length - 1], prev = rows[rows.length - 2], i = fuel === "e10" ? 1 : 2;
  const d = prev ? Math.round((last[i] - prev[i]) * 1000) / 10 : null;
  return { p: last[i], src: `CBS-gemiddelde · ${dayLabel(last[0])}${d != null ? ` · ${d > 0 ? "+" : d < 0 ? "−" : "±"}${fmt(Math.abs(d), 1)} ct` : ""}` };
}
function tripKm(s) { return S.home ? haversine([S.home.lat, S.home.lng], [s.lat, s.lng]) * 2 * ROAD : null; }
function netSave(s) {
  const p = s[S.fuel]; if (!p) return null;
  const { L, use } = settings(), km = tripKm(s) ?? 0;
  return (nlPrice().p - p) * L - km * use / 100 * p;
}
function regionStations() { const c = S.cache[S.region]; return c ? c.stations.filter((s) => s.border <= S.maxB) : []; }
function filtered(requirePrice = true) {
  return regionStations().filter((s) => (!requirePrice || s[S.fuel]) && (!S.openOnly || s.isOpen) && (!S.noHwy || !s.hwy)
    && (!S.brand || (s.brand || s.name) === S.brand) && (!S.favOnly || S.favs.has(s.id)));
}
function median(a) { if (!a.length) return null; const b = [...a].sort((x, y) => x - y), m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; }
function classOf(p, med) { if (p == null || med == null) return "off"; return p <= med - 0.03 ? "good" : p >= med + 0.03 ? "bad" : "mid"; }
const CLS_LABEL = { good: "Goedkoop", mid: "Gemiddeld", bad: "Relatief duur", off: "Geen prijs" };
function sorted(list) {
  const f = S.fuel, by = {
    price: (a, b) => a[f] - b[f], border: (a, b) => a.border - b.border,
    home: (a, b) => (tripKm(a) ?? 0) - (tripKm(b) ?? 0), net: (a, b) => (netSave(b) ?? -1e9) - (netSave(a) ?? -1e9)
  }[S.sort] || ((a, b) => a[f] - b[f]);
  return [...list].sort(by);
}
function bestNet() { return sorted(filtered()).slice().sort((a, b) => (netSave(b) ?? -1e9) - (netSave(a) ?? -1e9))[0] || null; }

// ---------- prijsalarm ----------
function checkAlert() {
  for (const f of ["e10", "diesel", "e5"]) {
    const target = S.alert[f]; if (!target) continue;
    const c = S.cache[S.region]; if (!c) continue;
    const hits = c.stations.filter((s) => s.isOpen && s[f] && !s.hwy && s[f] <= target).sort((a, b) => a[f] - b[f]);
    if (!hits.length) continue;
    const s = hits[0], msg = `${FUELNAME[f]} voor ${fmt(s[f])} bij ${s.brand || s.name}, ${s.place.replace(/^\d+\s/, "")} (doel ${fmt(target)}).`;
    S.alertHit = msg;
    if (Date.now() - (S.alertLast[f] || 0) > 3 * 3600e3) {
      S.alertLast[f] = Date.now(); store.set("tw_alertLast", S.alertLast);
      try {
        if ("Notification" in window && Notification.permission === "granted") {
          navigator.serviceWorker?.ready.then((r) => r.showNotification("Prijsalarm Tankwijzer", { body: msg, icon: "icons/icon-192.png", tag: "tw-" + f }))
            .catch(() => new Notification("Prijsalarm Tankwijzer", { body: msg }));
        }
      } catch (e) {}
    }
  }
}

// ---------- tankmoment ----------
function renderMoment() {
  const h = +new Intl.DateTimeFormat("nl-NL", { timeZone: "Europe/Berlin", hour: "numeric", hour12: false }).format(new Date());
  const dow = new Date().getDay();
  let k, t;
  if (h >= 9 && h < 12) { k = "nu"; t = "Tank in Duitsland vóór 12:00. Om 12 uur gaan de prijzen in één keer omhoog, gemiddeld 15 à 18 cent."; }
  else if (h >= 12 && h < 15) { k = "wacht"; t = "De Duitse prijzen zijn net verhoogd. Kan het wachten, dan zakken ze in de loop van de dag weer; het laagst is het meestal vlak vóór 12:00."; }
  else if (h >= 15) { k = "later"; t = "De Duitse prijzen zakken weer na de verhoging van 12 uur. Morgen vlak vóór 12:00 is meestal het goedkoopste moment."; }
  else { k = "ochtend"; t = "De Duitse prijzen blijven tot 12:00 op of onder het huidige niveau."; }
  if (dow === 1) t += " In Nederland is maandag vaak de duurste tankdag.";
  $("moment").innerHTML = `<b>${k}</b><span>${t}</span>`;
}

// ---------- render ----------
function render() {
  const c = S.cache[S.region], st = $("status");
  if (!S.key) { st.className = "status"; $("statusTxt").textContent = "Geen API-sleutel"; }
  else if (S.busy) { st.className = "status"; $("statusTxt").textContent = "Prijzen ophalen…"; }
  else if (S.error) { st.className = "status err"; $("statusTxt").textContent = "Fout · " + (c ? "prijzen van " + hhmm(c.priceTs) : "geen gegevens"); }
  else if (c) { const fresh = Date.now() - c.priceTs < 15 * 60000; st.className = "status " + (fresh ? "live" : "stale"); $("statusTxt").textContent = (fresh ? "Live · " : "Verouderd · ") + "prijzen van " + hhmm(c.priceTs); }
  $("keyBanner").hidden = !!S.key;
  const ab = $("alertBanner"); ab.hidden = !S.alertHit; if (S.alertHit) ab.innerHTML = `<strong>Prijsalarm</strong><span class="note">${esc(S.alertHit)}</span>`;
  renderMoment();

  // pompen + oordeel
  const nl = nlPrice(), list = filtered(), cheapest = sorted(list).sort((a, b) => a[S.fuel] - b[S.fuel])[0];
  $("ledNL").innerHTML = fmt(nl.p) + "<small>€/L</small>"; $("srcNL").textContent = nl.src;
  $("ledDE").innerHTML = (cheapest ? fmt(cheapest[S.fuel]) : "–") + "<small>€/L</small>";
  $("srcDE").textContent = cheapest ? `${cheapest.brand || cheapest.name}, ${cheapest.place.replace(/^\d+\s/, "")} · ${fmt(cheapest.border, 1)} km van grens` : (S.key ? "Nog geen prijzen" : "Sleutel nodig voor live prijzen");
  const v = $("verdict"), best = bestNet();
  if (cheapest) {
    const d = nl.p - cheapest[S.fuel], n = best ? netSave(best) : null;
    v.className = "verdict " + (d > 0 ? "good" : "bad");
    $("vBig").textContent = (d >= 0 ? "−" : "+") + Math.round(Math.abs(d) * 100) + " ct";
    $("vHead").textContent = d > 0 ? `${FUELNAME[S.fuel]} is ${Math.round(d * 100)} cent per liter goedkoper over de grens` : `${FUELNAME[S.fuel]} is in Nederland nu niet duurder`;
    $("vSub").textContent = best && S.home ? (n > 0 ? `Vanaf ${S.home.name} houd je netto ${eur(n)} over per tankbeurt bij ${best.brand || best.name} in ${best.place.replace(/^\d+\s/, "")}.` : `Vanaf ${S.home.name} kost het omrijden meer dan je bespaart.`) : `Bij 50 liter scheelt dat ${eur(d * 50)}, nog zonder omrijkosten.`;
  } else { v.className = "verdict"; $("vBig").textContent = "–"; $("vHead").textContent = "Nog geen Duitse prijzen"; $("vSub").textContent = S.key ? "Even geduld, de prijzen worden opgehaald." : "Vul je Tankerkönig-sleutel in onder Meer."; }

  // merkfilter vullen
  const brands = [...new Set(regionStations().map((s) => s.brand || s.name))].sort((a, b) => a.localeCompare(b));
  const bs = $("brand"); const html = `<option value="">Alle merken</option>` + brands.map((b) => `<option>${esc(b)}</option>`).join("");
  if (bs.innerHTML !== html) { bs.innerHTML = html; bs.value = brands.includes(S.brand) ? S.brand : ""; }

  $("homeNote").innerHTML = S.home ? `Vertrekpunt: <b>${esc(S.home.name)}</b> · ${settings().L} L, ${fmt(settings().use, 1)} L/100 km · <a href="#" data-goto="bespaar">wijzig</a>` : "";
  $("listNote").textContent = S.error || (S.key === DEMO_KEY ? "Demodata: dit zijn geen echte prijzen." : c ? `${list.length} van ${regionStations().length} stations in ${REGIONS[S.region].name} (binnen ${S.maxB} km van de grens). Prijzen verversen elke 5 minuten zolang de app open is.` : "");
  $("refresh").disabled = S.busy || !S.key;

  renderList(list); renderMap(); renderDays(); renderCalc(); renderFills(); renderCheck();
  $("alertFuel").textContent = FUELNAME[S.fuel];
  if (document.activeElement !== $("alertP")) $("alertP").value = S.alert[S.fuel] || "";
}

function stationRow(s, i, med, opts = {}) {
  const p = s[S.fuel], cls = classOf(p, med), n = netSave(s), km = tripKm(s), fav = S.favs.has(s.id), open = S.open === s.id;
  const d = S.details[s.id];
  let detail = "";
  if (open && !opts.near) {
    const hrs = d ? (d.error ? esc(d.error) : d.wholeDay ? "24 uur per dag open" : (d.openingTimes || []).map((o) => `${esc(o.text)} ${esc(o.start?.slice(0, 5))}–${esc(o.end?.slice(0, 5))}`).join(" · ") || "Openingstijden onbekend") : "Openingstijden laden…";
    detail = `<div class="detail">
      <div class="prices"><span>E10 ${fmt(s.e10)}</span><span>E5 ${fmt(s.e5)}</span><span>Diesel ${fmt(s.diesel)}</span></div>
      <div class="hrs">${hrs}</div>
      ${km != null ? `<div>Rijden vanaf ${esc(S.home.name)}: ±${Math.round(km)} km heen en terug</div><div>Netto: <b class="${n >= 0 ? "pos" : "neg"}">${eur(n)}</b> per ${settings().L} L</div>` : ""}
      <div class="acts"><a class="btn" href="https://www.google.com/maps/dir/?api=1&destination=${s.lat},${s.lng}" target="_blank" rel="noopener">Google Maps</a><a class="btn sec" href="https://waze.com/ul?ll=${s.lat},${s.lng}&navigate=yes" target="_blank" rel="noopener">Waze</a><button class="btn sec" data-log="${s.id}">Getankt? Noteer</button></div></div>`;
  }
  return `<div class="st" data-id="${s.id}"><span class="rank">${i + 1}</span>
    <div class="nm"><b>${opts.near ? "" : `<button class="star${fav ? " on" : ""}" data-fav="${s.id}" aria-label="${fav ? "Verwijder uit" : "Voeg toe aan"} favorieten">${fav ? "★" : "☆"}</button>`}${esc(s.brand || s.name)}${s.hwy ? '<span class="tag">Snelweg</span>' : ""}</b><span>${esc(s.street)}, ${esc(s.place)}</span></div>
    <span class="pr">${fmt(p)}</span>
    <div class="meta"><span class="pill ${s.isOpen ? cls : "off"}"><i class="dot"></i>${s.isOpen ? CLS_LABEL[cls] : "Gesloten"}</span>
      ${s.border != null ? `<span>${fmt(s.border, 1)} km van grens</span>` : ""}${s.dist != null ? `<span>${fmt(s.dist, 1)} km van jou</span>` : ""}
      ${opts.near ? `<a href="https://www.google.com/maps/dir/?api=1&destination=${s.lat},${s.lng}" target="_blank" rel="noopener">Route</a>` : ""}
      ${n != null && km != null && !opts.near ? `<span class="net ${n >= 0 ? "pos" : "neg"}">netto ${eur(n)}</span>` : n != null ? `<span>${eur((nlPrice().p - p) * settings().L)} goedkoper per ${settings().L} L</span>` : ""}
    </div>${detail}</div>`;
}
function renderList(list) {
  const med = median(list.map((s) => s[S.fuel]));
  const s = sorted(list);
  $("list").innerHTML = s.length ? s.map((x, i) => stationRow(x, i, med)).join("")
    : `<div class="empty">${S.key ? (S.busy ? "Stations laden…" : S.favOnly ? "Nog geen favorieten in deze regio. Tik op ☆ bij een station." : "Geen stations die aan je filters voldoen.") : "Live stations verschijnen hier zodra je API-sleutel is ingevuld."}</div>`;
}

// ---------- kaart ----------
let map, layer;
function renderMap() {
  if (S.tab !== "kaart" || typeof L === "undefined") return;
  if (!map) {
    map = L.map("map").setView([51.9, 6.4], 8);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 18, attribution: "© OpenStreetMap" }).addTo(map);
    L.polyline(BORDER, { color: "#888", weight: 2, dashArray: "6 6" }).addTo(map);
    layer = L.layerGroup().addTo(map);
  }
  setTimeout(() => map.invalidateSize(), 50);
  layer.clearLayers();
  const all = filtered(false), med = median(filtered().map((s) => s[S.fuel]));
  const css = getComputedStyle(document.documentElement), col = (v) => css.getPropertyValue(v).trim();
  const colors = { good: col("--good"), mid: col("--mid"), bad: col("--bad"), off: col("--muted") };
  all.forEach((s) => {
    const p = s[S.fuel], cls = s.isOpen ? classOf(p, med) : "off", n = netSave(s);
    L.circleMarker([s.lat, s.lng], { radius: S.favs.has(s.id) ? 10 : 8, color: S.favs.has(s.id) ? col("--led") : "#fff", weight: 2, fillColor: colors[cls], fillOpacity: 0.95 })
      .bindPopup(`<b>${esc(s.brand || s.name)}</b>${s.hwy ? " (snelweg)" : ""}<br>${esc(s.street)}, ${esc(s.place)}<br><b style="font-size:1.15em">${fmt(p)} €/L</b> ${s.isOpen ? "" : "(gesloten)"}<br>${n != null && S.home ? "Netto vanaf " + esc(S.home.name) + ": " + eur(n) + "<br>" : ""}<a href="https://www.google.com/maps/dir/?api=1&destination=${s.lat},${s.lng}" target="_blank" rel="noopener">Google Maps</a> · <a href="https://waze.com/ul?ll=${s.lat},${s.lng}&navigate=yes" target="_blank" rel="noopener">Waze</a>`)
      .addTo(layer);
  });
  if (S.home) L.circleMarker([S.home.lat, S.home.lng], { radius: 7, color: "#fff", weight: 2, fillColor: col("--accent"), fillOpacity: 1 }).bindPopup("Vertrekpunt: " + esc(S.home.name)).addTo(layer);
  const pts = all.length ? all.map((s) => [s.lat, s.lng]) : REGIONS[S.region].pts, key = S.region + all.length;
  if (map._twKey !== key) { map.fitBounds(L.latLngBounds(pts).pad(0.15)); map._twKey = key; }
}

// ---------- dagprijzen ----------
const deDay = (k, f) => { const d = S.hist[k]?.[S.region]?.[f]; return d && d[1] ? d[0] / d[1] : null; };
function renderDays() {
  if (S.tab !== "dag") return;
  const rows = cbsRows(), nlIdx = S.fuel === "diesel" ? 2 : 1, deF = S.fuel === "e5" ? "e10" : S.fuel;
  const days = new Set(rows.map((r) => r[0])); Object.keys(S.hist).forEach((k) => days.add(k));
  const keys = [...days].sort().slice(-45), nlMap = Object.fromEntries(rows.map((r) => [r[0], r]));
  const nlS = keys.map((k) => nlMap[k]?.[nlIdx] ?? null), deS = keys.map((k) => deDay(k, deF));
  const showNL = S.fuel !== "e5", vals = [...(showNL ? nlS : []), ...deS].filter((v) => v != null), svg = $("chart");
  if (!vals.length) { svg.innerHTML = ""; }
  else {
    let lo = Math.min(...vals), hi = Math.max(...vals); const pv = Math.max(0.03, (hi - lo) * 0.15); lo -= pv; hi += pv;
    const W = 400, H = 230, l = 40, r = 8, t = 10, b = 24;
    const X = (i) => l + (keys.length < 2 ? 0 : i * (W - l - r) / (keys.length - 1)), Y = (v) => t + (hi - v) * (H - t - b) / (hi - lo);
    let g = "";
    for (let i = 0; i <= 4; i++) { const v = lo + (hi - lo) * i / 4; g += `<line x1="${l}" x2="${W - r}" y1="${Y(v)}" y2="${Y(v)}" stroke="currentColor" opacity=".15"/><text x="${l - 5}" y="${Y(v) + 4}" text-anchor="end">${fmt(v, 2)}</text>`; }
    const step = Math.ceil(keys.length / 5);
    keys.forEach((k, i) => { if (i % step === 0 || i === keys.length - 1) g += `<text x="${X(i)}" y="${H - 6}" text-anchor="${i === keys.length - 1 ? "end" : i === 0 ? "start" : "middle"}">${dayLabel(k)}</text>`; });
    const path = (s) => { let d = "", pen = false; s.forEach((v, i) => { if (v == null) { pen = false; return; } d += (pen ? "L" : "M") + X(i).toFixed(1) + " " + Y(v).toFixed(1); pen = true; }); return d; };
    const last = (s, c) => { for (let i = s.length - 1; i >= 0; i--) if (s[i] != null) return `<circle cx="${X(i)}" cy="${Y(s[i])}" r="3.5" fill="${c}"/>`; return ""; };
    svg.style.color = "var(--muted)";
    svg.innerHTML = g + (showNL ? `<path d="${path(nlS)}" fill="none" stroke="var(--nl)" stroke-width="2.5"/>${last(nlS, "var(--nl)")}` : "") + `<path d="${path(deS)}" fill="none" stroke="var(--de)" stroke-width="2.5"/>${last(deS, "var(--de)")}`;
  }
  const lastNL = rows[rows.length - 1];
  $("dayNote").textContent = `${FUELNAME[S.fuel]}${S.fuel === "e5" ? " (NL: geen CBS-reeks; DE toont E10)" : ""}. Laatste CBS-dag: ${dayLabel(lastNL[0])}. Duitse lijn: regio ${REGIONS[S.region].name}, zonder snelwegstations.`;
  const delta = (k, i) => { const idx = rows.findIndex((r) => r[0] === k); if (idx < 1) return ""; const d = Math.round((rows[idx][i] - rows[idx - 1][i]) * 1000) / 10; return `<span class="${d > 0 ? "neg" : d < 0 ? "pos" : ""}">${d > 0 ? "+" : d < 0 ? "−" : "±"}${fmt(Math.abs(d), 1)}</span>`; };
  $("dayBody").innerHTML = [...keys].reverse().slice(0, 14).map((k) => {
    const n = nlMap[k];
    return `<tr><td>${dayLabel(k)}</td><td class="n">${fmt(n?.[1])}</td><td class="n">${n ? delta(k, 1) : ""}</td><td class="n">${fmt(n?.[2])}</td><td class="n">${n ? delta(k, 2) : ""}</td><td class="n">${fmt(deDay(k, "e10"))}</td><td class="n">${fmt(deDay(k, "diesel"))}</td></tr>`;
  }).join("");
}

// ---------- bespaar ----------
function renderCalc() {
  const { freq } = settings(), b = bestNet();
  $("cNL").placeholder = fmt(nlPrice().p);
  if (document.activeElement !== $("cNL")) $("cNL").value = S.nlOwn[S.fuel] || "";
  if (!b) { ["rBest", "rDiff", "rKm", "rDetour", "rNet", "rYear"].forEach((id) => $(id).textContent = "–"); $("rNote").textContent = "Wacht op live Duitse prijzen."; return; }
  const p = b[S.fuel], km = tripKm(b) ?? 0, n = netSave(b), { use } = settings();
  $("rBest").textContent = `${b.brand || b.name}, ${b.place.replace(/^\d+\s/, "")} (${fmt(p)})`;
  $("rDiff").textContent = Math.round((nlPrice().p - p) * 100) + " ct";
  $("rKm").textContent = "±" + Math.round(km) + " km";
  $("rDetour").textContent = eur(-km * use / 100 * p);
  $("rNet").textContent = eur(n); $("rNet").className = n >= 0 ? "pos" : "neg";
  $("rYear").textContent = eur(n * freq * 12); $("rYear").className = n >= 0 ? "pos" : "neg";
  $("rNote").textContent = n > 0 ? `Gerekend met de huidige filters in ${REGIONS[S.region].name}. Reistijd is niet meegerekend; rij-afstand is geschat.` : `Vanaf ${S.home?.name || "je vertrekpunt"} kost het rijden meer dan je bespaart. Tank meer liters of combineer het met een andere rit.`;
}
function renderFills() {
  const rows = [...S.fills].sort((a, b) => b.d.localeCompare(a.d));
  $("fBody").innerHTML = rows.length ? rows.map((r) => {
    const save = r.c === "DE" ? (r.nl - r.p) * r.l : null;
    return `<tr><td>${dayLabel(r.d.replace(/-/g, ""))}</td><td>${r.c}</td><td>${FUELNAME[r.f].split(" ")[0]}</td><td class="n">${fmt(r.l, 1)}</td><td class="n">${fmt(r.p)}</td><td class="n ${save > 0 ? "pos" : save < 0 ? "neg" : ""}">${save != null ? eur(save) : "–"}</td><td><button class="btn sec" style="padding:.1rem .5rem" data-delfill="${S.fills.indexOf(r)}" aria-label="Verwijder">✕</button></td></tr>`;
  }).join("") : `<tr><td colspan="7" class="note">Nog geen tankbeurten. Voeg er hierboven een toe, of tik bij een station op "Getankt? Noteer".</td></tr>`;
  const yr = String(new Date().getFullYear()), thisYear = S.fills.filter((r) => r.d.startsWith(yr));
  const spent = thisYear.reduce((a, r) => a + r.l * r.p, 0), saved = thisYear.filter((r) => r.c === "DE").reduce((a, r) => a + (r.nl - r.p) * r.l, 0), liters = thisYear.reduce((a, r) => a + r.l, 0);
  $("fStats").innerHTML = thisYear.length ? `<div class="stat"><span>Uitgegeven ${yr}</span><b>${eur(spent)}</b></div><div class="stat"><span>Liters</span><b>${fmt(liters, 0)}</b></div><div class="stat"><span>Gem. €/L</span><b>${fmt(spent / liters)}</b></div><div class="stat"><span>Bespaard over de grens</span><b class="${saved >= 0 ? "pos" : "neg"}">${eur(saved)}</b></div>` : "";
}
function renderCheck() {
  const c = $("kC").value, p = +$("kP").value || 0;
  const ref = c === "nl" ? nlPrice().p : median(filtered().map((s) => s[S.fuel])), pill = $("kPill");
  if (ref == null) { pill.className = "pill off"; pill.textContent = "Geen vergelijking"; $("kTxt").textContent = "Nog geen Duitse prijzen geladen."; return; }
  const cls = p <= ref - 0.05 ? "good" : p >= ref + 0.05 ? "bad" : "mid";
  pill.className = "pill " + cls; pill.innerHTML = '<i class="dot"></i>' + CLS_LABEL[cls];
  const d = Math.round((p - ref) * 100);
  $("kTxt").textContent = `${Math.abs(d)} cent ${d <= 0 ? "onder" : "boven"} ${c === "nl" ? "de Nederlandse referentie" : "de mediaan van de grensstations"} (${fmt(ref)}).`;
}

// ---------- dichtbij ----------
$("nearBtn").addEventListener("click", () => {
  if (!S.key) { $("nearList").innerHTML = '<div class="empty">Vul eerst je API-sleutel in onder Meer.</div>'; return; }
  if (!navigator.geolocation) { $("nearList").innerHTML = '<div class="empty">Je apparaat geeft geen locatie door.</div>'; return; }
  $("nearList").innerHTML = '<div class="empty">Locatie bepalen…</div>';
  navigator.geolocation.getCurrentPosition(async (pos) => {
    try {
      const j = await api("list.php", { lat: pos.coords.latitude.toFixed(4), lng: pos.coords.longitude.toFixed(4), rad: 10, sort: "dist", type: "all" });
      const l = (j.stations || []).map((s) => ({ ...toStation(s), dist: s.dist })).filter((s) => s[S.fuel] && s.isOpen).sort((a, b) => a[S.fuel] - b[S.fuel]).slice(0, 15);
      const med = median(l.map((s) => s[S.fuel]));
      $("nearList").innerHTML = l.length ? l.map((s, i) => stationRow(s, i, med, { near: true })).join("") : '<div class="empty">Geen open Duitse stations binnen 10 km. Dit werkt alleen in of vlak bij Duitsland.</div>';
    } catch (e) { $("nearList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
  }, () => { $("nearList").innerHTML = '<div class="empty">Geen toegang tot je locatie. Sta locatie toe voor deze app in je instellingen.</div>'; }, { timeout: 15000, maximumAge: 300000 });
});

// ---------- bediening ----------
function nearestRegion(lat, lng) {
  let best = null, bd = Infinity;
  for (const [k, r] of Object.entries(REGIONS)) for (const p of r.pts) { const d = haversine([lat, lng], p); if (d < bd) { bd = d; best = k; } }
  return best;
}
function setHome(h, pickRegion = true) {
  S.home = h; store.set("tw_home", h);
  if (pickRegion) { const r = nearestRegion(h.lat, h.lng); if (r && r !== S.region) { S.region = r; store.set("tw_region", r); $("region").value = r; update(); } }
  render();
}
$("homeSel").innerHTML = CITIES.map(([n]) => `<option>${n}</option>`).join("") + `<option value="__gps">Mijn locatie</option>`;
$("homeSel").value = CITIES.some(([n]) => n === S.home?.name) ? S.home.name : "__gps";
$("homeSel").addEventListener("change", (e) => { const c = CITIES.find(([n]) => n === e.target.value); if (c) setHome({ name: c[0], lat: c[1], lng: c[2] }); else $("homeGps").click(); });
$("homeGps").addEventListener("click", () => {
  if (!navigator.geolocation) return;
  $("homeGps").textContent = "Locatie bepalen…";
  navigator.geolocation.getCurrentPosition((p) => { $("homeGps").textContent = "Gebruik mijn locatie"; $("homeSel").value = "__gps"; setHome({ name: "mijn locatie", lat: p.coords.latitude, lng: p.coords.longitude }); },
    () => { $("homeGps").textContent = "Geen toegang tot locatie"; }, { timeout: 15000 });
});

$("region").innerHTML = Object.entries(REGIONS).map(([k, r]) => `<option value="${k}">${r.name}</option>`).join("");
$("region").value = S.region;
$("region").addEventListener("change", (e) => { S.region = e.target.value; store.set("tw_region", S.region); S.brand = ""; update(); });
document.querySelectorAll("[data-fuel]").forEach((b) => {
  b.setAttribute("aria-pressed", b.dataset.fuel === S.fuel);
  b.addEventListener("click", () => { S.fuel = b.dataset.fuel; store.set("tw_fuel", S.fuel); document.querySelectorAll("[data-fuel]").forEach((x) => x.setAttribute("aria-pressed", x === b)); render(); });
});
$("maxB").value = S.maxB; $("maxBLbl").textContent = S.maxB + " km";
$("maxB").addEventListener("input", (e) => { S.maxB = +e.target.value; $("maxBLbl").textContent = S.maxB + " km"; store.set("tw_maxB", S.maxB); render(); });
$("sort").value = S.sort; $("sort").addEventListener("change", (e) => { S.sort = e.target.value; store.set("tw_sort", S.sort); render(); });
$("brand").addEventListener("change", (e) => { S.brand = e.target.value; store.set("tw_brand", S.brand); render(); });
[["openOnly", "openOnly", "tw_open"], ["noHwy", "noHwy", "tw_nohwy"], ["favOnly", "favOnly", "tw_favonly"]].forEach(([id, k, sk]) => {
  $(id).checked = S[k]; $(id).addEventListener("change", (e) => { S[k] = e.target.checked; store.set(sk, S[k]); render(); });
});
$("refresh").addEventListener("click", () => update(true));
["cLiters", "cUse", "cFreq"].forEach((id) => { const v = store.get("tw_" + id, null); if (v != null) $(id).value = v; $(id).addEventListener("input", () => { store.set("tw_" + id, $(id).value); render(); }); });
$("cNL").addEventListener("change", () => { const v = parseFloat($("cNL").value); if (v > 0.5 && v < 5) S.nlOwn[S.fuel] = v; else delete S.nlOwn[S.fuel]; store.set("tw_nlOwn", S.nlOwn); render(); });
$("kC").addEventListener("change", renderCheck); $("kP").addEventListener("input", renderCheck);

// lijst: favoriet, details, noteren
$("list").addEventListener("click", (e) => {
  const fav = e.target.closest("[data-fav]"); if (fav) { e.stopPropagation(); const id = fav.dataset.fav; S.favs.has(id) ? S.favs.delete(id) : S.favs.add(id); store.set("tw_favs", [...S.favs]); render(); return; }
  const lg = e.target.closest("[data-log]");
  if (lg) {
    const s = regionStations().find((x) => x.id === lg.dataset.log);
    if (s) { showTab("bespaar"); $("fC").value = "DE"; $("fP").value = s[S.fuel] || ""; $("fL").value = settings().L; $("fL").focus(); }
    return;
  }
  if (e.target.closest("a,button")) return;
  const row = e.target.closest(".st"); if (!row) return;
  S.open = S.open === row.dataset.id ? null : row.dataset.id; render();
  if (S.open) loadDetail(S.open);
});

// tankbeurten
$("fDate").value = new Date().toISOString().slice(0, 10);
$("fAdd").addEventListener("click", () => {
  const d = $("fDate").value, l = parseFloat($("fL").value), p = parseFloat($("fP").value), c = $("fC").value;
  if (!d || !(l > 0) || !(p > 0.5 && p < 5)) { $("fL").focus(); return; }
  const nl = S.nlOwn[S.fuel] || (S.fuel === "e5" ? NL_SUPER_ADVIES.price : cbsOn(d.replace(/-/g, ""), S.fuel));
  S.fills.push({ d, c, f: S.fuel, l, p, nl }); store.set("tw_fills", S.fills);
  $("fL").value = ""; $("fP").value = ""; render();
});
$("fBody").addEventListener("click", (e) => { const b = e.target.closest("[data-delfill]"); if (b) { S.fills.splice(+b.dataset.delfill, 1); store.set("tw_fills", S.fills); render(); } });

// prijsalarm
$("alertP").addEventListener("change", () => {
  const v = parseFloat($("alertP").value);
  if (v > 0.5 && v < 5) S.alert[S.fuel] = v; else delete S.alert[S.fuel];
  store.set("tw_alert", S.alert); S.alertHit = null; delete S.alertLast[S.fuel]; checkAlert();
  $("alertMsg").textContent = S.alert[S.fuel] ? `Alarm staat op ${fmt(v)} voor ${FUELNAME[S.fuel]}.` : "Alarm uit."; render();
});
$("alertPerm").addEventListener("click", async () => {
  if (!("Notification" in window)) { $("alertMsg").textContent = "Dit apparaat ondersteunt geen meldingen. Op een iPhone werkt het alleen als de app op je beginscherm staat."; return; }
  const r = await Notification.requestPermission();
  $("alertMsg").textContent = r === "granted" ? "Meldingen staan aan." : "Meldingen zijn niet toegestaan; je ziet het alarm dan alleen in de app.";
});

// sleutel
$("apiKey").value = S.key === DEMO_KEY ? "" : S.key;
$("saveKey").addEventListener("click", () => {
  const k = $("apiKey").value.trim();
  if (!/^[0-9a-f-]{36}$/i.test(k)) { $("keyMsg").textContent = "Dit lijkt geen geldige sleutel. Hij bestaat uit 36 tekens, zoals xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx."; return; }
  S.key = k; store.set("tw_key", k); S.cache = {}; store.set("tw_cache", {}); $("keyMsg").textContent = "Opgeslagen. Live prijzen worden opgehaald.";
  showTab("lijst"); update("list");
});
$("demoKey").addEventListener("click", () => { S.key = DEMO_KEY; store.set("tw_key", DEMO_KEY); S.cache = {}; $("keyMsg").textContent = "Demomodus aan: de prijzen zijn niet echt."; showTab("lijst"); update("list"); });
$("clearCache").addEventListener("click", () => { S.cache = {}; S.hist = {}; S.cbs = null; store.set("tw_cache", {}); store.set("tw_hist", {}); store.set("tw_cbs", null); loadCBS(); update("list"); });

function showTab(t) {
  S.tab = t; store.set("tw_tab", t);
  document.querySelectorAll("[data-tab]").forEach((b) => b.setAttribute("aria-selected", b.dataset.tab === t));
  document.querySelectorAll("[data-view]").forEach((v) => v.hidden = v.dataset.view !== t);
  window.scrollTo(0, 0); render();
}
document.querySelectorAll("[data-tab]").forEach((b) => b.addEventListener("click", () => showTab(b.dataset.tab)));
document.addEventListener("click", (e) => { const g = e.target.closest("[data-goto]"); if (g) { e.preventDefault(); showTab(g.dataset.goto); } });

// ---------- verversen: start, terug in beeld, elke 5 minuten ----------
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") { update(); loadCBS(); } });
setInterval(() => { if (document.visibilityState === "visible") update(); else render(); }, 60 * 1000);
window.addEventListener("online", () => update());

showTab(S.tab);
loadCBS();
update();
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
